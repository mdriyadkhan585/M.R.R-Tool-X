#!/bin/bash
#code_recorded_by_tech_cochi
clear
sleep 1
echo ""
echo ""
echo " 
████████╗███████╗░█████╗░██╗░░██╗
╚══██╔══╝██╔════╝██╔══██╗██║░░██║
░░░██║░░░█████╗░░██║░░╚═╝███████║
░░░██║░░░██╔══╝░░██║░░██╗██╔══██║
░░░██║░░░███████╗╚█████╔╝██║░░██║
░░░╚═╝░░░╚══════╝░╚════╝░╚═╝░░╚═╝ " | lolcat




echo ""
sleep 1
clear

pkg install php -y
pkg install openssh -y
pkg install unzip -y
pkg install curl -y
sleep 1
clear

echo "Loading==> " | lolcat
sleep 1
clear
echo "Loading====> " | lolcat
sleep 1
clear
echo "Loading=======> " | lolcat
sleep 1
clear
echo " done " | lolcat
sleep 1
clear
unzip techcochi.zip
clear
rm -rf techcochi.zip
clear
bash about.sh
sleep 4
echo ""
echo ""
echo " SUBSCRIBE MY CHANNEL 🔔 " | lolcat
xdg-open https://www.youtube.com/channel/HYDRAGAMING4U
echo ""
sleep 10
echo " create account on cashkaro.com "
echo " set your browser "
termux-open-url https://cashkaro.com?r=8026255&fname=Rixon
echo ""
