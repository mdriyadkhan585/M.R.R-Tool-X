* Overview is under construction

### Command line

```
$  apt update && apt upgrade

$  apt install python2

$  apt install git

$  git clone https://github.com/bhikandeshmukh/fbreport.git

$  cd fbreport

$  ls

$  unzip Report.zip

$  python2 Report.py
```

<Img src="Stock/Report.png">

<h2 align="center">To Know about Ethical Hacking , Android And Kali Linux Do Follow Us:-</h2>
<p align="center">
<a href="https://t.me/dev_aladdin"><img title="Telegram" src="https://img.shields.io/badge/Telegram-black?style=for-the-badge&logo=Telegram"></a>
<a href="https://wa.me/918600525401"><img title="whatsapp" src="https://img.shields.io/badge/WHATSAPP-%2325D366.svg?&style=for-the-badge&logo=whatsapp&logoColor=white"></a>
<a href="https://www.instagram.com/bhikan_deshmukh/"><img title="Instagram" src="https://img.shields.io/badge/instagram-%23E4405F.svg?&style=for-the-badge&logo=instagram&logoColor=white"></a>
<a href="https://www.instamojo.com/@deepanshunarwal/"><img title="DONATE" src="https://img.shields.io/badge/DONATE-lightgrey?style=for-the-badge&logo=Google-pay"></a>
</p>
