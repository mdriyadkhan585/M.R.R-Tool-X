
# HACKING TOOLS                   

[![Build Status](https://img.shields.io/github/forks/rixon-cochi/hacking-tool.svg)](https://github.com/rixon-cochi/hacking-tool)
[![Build Status](https://img.shields.io/github/stars/rixon-cochi/hacking-tool.svg)](https://github.com/rixon-cochi/hacking-tool)
[![License](https://img.shields.io/github/license/rixon-cochi/b.svg)](https://github.com/rixon-cochi/b)

-----------------------------------------------------------------------------------------------------------------------------------
<br>
<p align="center">
<img width="35%" src="https://i.pinimg.com/originals/93/92/55/939255731017e8a035c18bfb82c1c52b.png"/>
</p>

<p align="center">
      TERMUX HACKING TOOLS INSTALLATION SETUP 🗂️
</p> 
<p align="center">
     CODE BY TECH COCHI  
</p>

------------------------------------------------------------------------------------------------------

### Introduction

* hacking tool recorded by tech cochi
15 hacking tools included in this code

-------------------------------------------------------------------------------------

### Operating System Requirements

hacking-tool works on 

• **Android** (Using the Termux App) <br>

-------------------------------------------------------------------------------------

## Legal disclaimer:

Usage of hacking-tool for attacking targets without prior mutual consent is illegal.
It's the end user's responsibility to obey all applicable local, state and federal laws.
Developers assume no liability and are not responsible for any misuse or damage caused by this program

### How to Install ?

Open the terminal and type following commands.

* `apt update`

* `apt install git`

* `git clone https://github.com/rixon-cochi/hacking-tool.git`

* `cd hacking-tool`

* `bash install.sh`

* `bash tools.sh`

* ~~sh tools.sh~~ not work 

* ~~./tools.sh~~ not work

## preview
![](https://i.pinimg.com/originals/db/4f/04/db4f045299041f244c2b5a33580ff8b8.gif)

# SUPPORT 
[![Donate](https://img.shields.io/badge/paypal-TECH--COCHI-gold?style=for-the-badge&logo=PayPal)](https://www.paypal.me/techcochi)
[![YouTube](https://img.shields.io/badge/youtube-TECH--COCHI-red?style=for-the-badge&logo=youtube)](https://www.youtube.com/c/HYDRAGAMING4U)
