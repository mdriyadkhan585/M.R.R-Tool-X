#!/usr/bin/python
# -*- coding: utf-8 -*-

# name        : Example Title
# description : Example description
# author      : Wordpresscan Team

import requests

name = "Thank You"

def __init__(wordpress):
	# INSERT CODE HERE!
	print "Thank you for using this software :)"
	return
